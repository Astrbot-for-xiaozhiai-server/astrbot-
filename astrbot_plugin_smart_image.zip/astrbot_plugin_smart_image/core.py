"""Core image library for astrbot_plugin_smart_image.

This module deliberately has no AstrBot imports, so the storage, search and
learning logic can be unit-tested without a running AstrBot instance.
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import re
import secrets
import shutil
import threading
import time
import unicodedata
from collections import Counter
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Iterable

try:  # Pillow is bundled with most AstrBot installations, but it is optional.
    from PIL import Image as PILImage
except Exception:  # pragma: no cover - optional dependency
    PILImage = None


PLUGIN_NAME = "astrbot_plugin_smart_image"
INDEX_VERSION = 1
DEFAULT_TAG = "未分类"
MAX_CAPTION_LEN = 400

_IMAGE_SIGNATURES = (
    (b"\xff\xd8\xff", "jpg"),
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"GIF87a", "gif"),
    (b"GIF89a", "gif"),
    (b"BM", "bmp"),
)

_STOPWORDS = {
    "的", "了", "是", "我", "你", "他", "她", "它", "我们", "你们", "他们",
    "一", "一个", "一只", "不", "在", "有", "和", "就", "都", "也", "很", "吗",
    "呢", "啊", "吧", "这", "那", "这个", "那个", "上", "下", "来", "去",
    "说", "要", "会", "可以", "什么", "怎么", "图片", "图", "发", "来张",
    "表情包", "表情", "一张", "这个图", "那个图", "看", "想看", "给我",
    "请", "谢谢", "感谢", "哈哈", "哈哈哈", "好的", "好吧", "行", "嗯",
    "哦", "收到", "ok", "okay", "the", "a", "an", "is", "are", "to",
    "of", "and", "or", "for", "in", "on", "at", "it", "this", "that",
}

_POSITIVE_WORDS = {
    "好", "好用", "好看", "可爱", "喜欢", "不错", "谢谢", "哈哈", "哈哈哈",
    "棒", "太棒", "爱了", "再来", "正确", "对了", "可以", "满意", "笑死",
    "牛", "赞", "厉害", "完美", "good", "nice", "love", "yes", "great",
    "perfect", "thanks", "cute",
}
_NEGATIVE_WORDS = {
    "不对", "不是", "错了", "错误", "对不起", "不要", "别发", "不好", "丑",
    "难看", "讨厌", "不行", "差", "垃圾", "无语", "停止", "停下", "换一张",
    "重来", "bad", "no", "wrong", "stop", "ugly", "hate",
}

_SKIP_LEARN_WORDS = ("不要学习", "别学习", "不要存", "别存", "不保存", "不要保存")
_SKIP_AUTO_WORDS = ("不要发图", "别发图", "停止发图", "不要图片", "别发图片", "别自动发图")

_URL_RE = re.compile(r"https?://[^\s]+", re.IGNORECASE)
_HASHTAG_RE = re.compile(r"[#＃]([^#＃\s]{1,32})[#＃]?")
_CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]+")
_LATIN_RE = re.compile(r"[a-zA-Z0-9_][a-zA-Z0-9_\-]*")
_CJK_STOP_CHARS = set(
    "的了是我你他她它一不在有和就都也很吗呢啊吧这那个上下来说要会好"
    "什么怎么图片发张只看想给请谢哈"
)


class ImageLibraryError(Exception):
    """Base error for user-facing library failures."""


class UnsupportedImage(ImageLibraryError):
    """The uploaded bytes are not a supported image format."""


class ImageTooLarge(ImageLibraryError):
    """The uploaded image exceeds the configured size limit."""


class ImageNotFound(ImageLibraryError):
    """No entry matched the supplied id."""


@dataclass
class AddResult:
    entry: "ImageEntry"
    created: bool
    changed: bool = False


@dataclass
class ImageEntry:
    id: str
    file: str
    sha256: str
    tags: list[str] = field(default_factory=list)
    caption: str = ""
    source: str = "upload"
    uploader_id: str = ""
    uploader_name: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    uses: int = 0
    likes: int = 0
    dislikes: int = 0
    last_used_at: float = 0.0
    enabled: bool = True
    penalty_until: float = 0.0
    size: int = 0
    width: int = 0
    height: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ImageEntry":
        allowed = {item.name for item in fields(cls)}
        clean = {key: value for key, value in data.items() if key in allowed}
        if not isinstance(clean.get("tags"), list):
            clean["tags"] = []
        clean["tags"] = [str(tag) for tag in clean["tags"] if str(tag).strip()]
        for key in ("uses", "likes", "dislikes", "width", "height", "size"):
            try:
                clean[key] = int(clean.get(key, 0) or 0)
            except (TypeError, ValueError):
                clean[key] = 0
        for key in ("created_at", "updated_at", "last_used_at", "penalty_until"):
            try:
                clean[key] = float(clean.get(key, 0) or 0)
            except (TypeError, ValueError):
                clean[key] = 0.0
        for key in (
            "id",
            "caption",
            "source",
            "uploader_id",
            "uploader_name",
            "file",
            "sha256",
        ):
            clean[key] = str(clean.get(key, "") or "")
        clean["enabled"] = bool(clean.get("enabled", True))
        return cls(**clean)


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).lower()
    text = text.replace("\u200b", "").replace("\ufeff", "")
    return re.sub(r"\s+", " ", text).strip()


def clean_tag(value: Any, max_len: int = 32) -> str:
    tag = normalize_text(value)
    tag = tag.lstrip("#＃").strip()
    tag = re.sub(r"[\x00-\x1f\x7f]", "", tag)
    tag = re.sub(r"\s+", " ", tag)
    return tag[:max_len].strip()


def clean_tags(tags: Iterable[Any], max_tags: int = 12, max_len: int = 32) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for raw in tags:
        tag = clean_tag(raw, max_len=max_len)
        if not tag or tag in seen:
            continue
        seen.add(tag)
        result.append(tag)
        if len(result) >= max_tags:
            break
    return result


def split_tags(text: str) -> list[str]:
    return [part for part in re.split(r"[\s,，、;；]+", str(text or "")) if part]


def split_caption(text: str) -> tuple[str, str]:
    parts = re.split(r"[|｜]", str(text or ""), maxsplit=1)
    if len(parts) == 1:
        return parts[0].strip(), ""
    return parts[0].strip(), parts[1].strip()


def extract_hashtags(text: str) -> list[str]:
    return [clean_tag(match) for match in _HASHTAG_RE.findall(str(text or "")) if clean_tag(match)]


def tokenize(text: str) -> list[str]:
    """A lightweight tokenizer that works for Chinese and space-delimited text."""
    normalized = normalize_text(text)
    tokens: list[str] = []
    seen: set[str] = set()

    def add(token: str) -> None:
        token = token.strip()
        if token and token not in seen:
            seen.add(token)
            tokens.append(token)

    for match in _LATIN_RE.findall(normalized):
        add(match)
    for match in _CJK_RE.findall(normalized):
        if len(match) <= 16:
            add(match)
        for index in range(len(match) - 1):
            gram = match[index : index + 2]
            if not any(char in _CJK_STOP_CHARS for char in gram):
                add(gram)
    for part in re.split(r"[\s,，、;；:：/\\()（）\[\]【】<>《》\"'“”‘’!?！？.。]+", normalized):
        add(part)
    return tokens


def extract_keywords(text: str, limit: int = 8) -> list[str]:
    """Extract searchable tags from a caption without a heavy NLP dependency.

    A caption is also stored separately, so this function intentionally favors
    precision over aggressive segmentation. Hashtags and short whitespace /
    punctuation separated phrases become tags; long sentences stay in caption.
    """
    source = str(text or "")
    tags = extract_hashtags(source)
    source = _URL_RE.sub(" ", source)

    for part in re.split(r"[\s,，、;；|｜:：/\\()（）\[\]【】<>《》\"'“”‘’!?！？.。]+", source):
        part = clean_tag(part, max_len=24)
        if not part or part in _STOPWORDS:
            continue
        if len(part) == 1:
            if (
                _CJK_RE.fullmatch(part)
                and part not in _CJK_STOP_CHARS
                and part not in _STOPWORDS
                and part not in tags
            ):
                tags.append(part)
            continue
        if len(part) < 2:
            continue
        if len(part) <= 24 and part not in tags:
            tags.append(part)
        # Add meaningful CJK bigrams as extra tags. This lets a sentence such
        # as "一只橘猫" be found by the shorter tag "橘猫" later.
        for run in _CJK_RE.findall(part):
            for index in range(len(run) - 1):
                gram = run[index : index + 2]
                if any(char in _CJK_STOP_CHARS for char in gram):
                    continue
                if gram not in tags:
                    tags.append(gram)
                if len(tags) >= limit:
                    break
            if len(tags) >= limit:
                break
        if len(tags) >= limit:
            break
    return tags


def _contains_word(text: str, word: str) -> bool:
    if word.isascii():
        return re.search(
            rf"(?<![a-z]){re.escape(word)}(?![a-z])", text
        ) is not None
    return word in text


def feedback_signal(text: str) -> int:
    normalized = normalize_text(text)
    if not normalized:
        return 0
    for word in _NEGATIVE_WORDS:
        if _contains_word(normalized, word):
            return -1
    for word in _POSITIVE_WORDS:
        if _contains_word(normalized, word):
            return 1
    return 0


def should_skip_learning(text: str) -> bool:
    normalized = normalize_text(text)
    return any(word in normalized for word in _SKIP_LEARN_WORDS)


def should_skip_auto_send(text: str) -> bool:
    normalized = normalize_text(text)
    return any(word in normalized for word in _SKIP_AUTO_WORDS)


def _longest_common_substring(left: str, right: str) -> int:
    if not left or not right:
        return 0
    previous = [0] * (len(right) + 1)
    best = 0
    for left_char in left:
        current = [0] * (len(right) + 1)
        for index, right_char in enumerate(right, start=1):
            if left_char == right_char:
                current[index] = previous[index - 1] + 1
                if current[index] > best:
                    best = current[index]
        previous = current
    return best


def human_size(size: int) -> str:
    value = float(max(0, int(size)))
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"


def short_id(entry_id: str) -> str:
    return entry_id[4:] if entry_id.startswith("img_") else entry_id


class ImageLibrary:
    """Thread-safe, JSON-backed image library with a recoverable trash."""

    def __init__(
        self,
        data_dir: str | Path,
        *,
        max_images: int = 2000,
        max_file_mb: int = 10,
        max_tags: int = 12,
        trash_retention_days: int = 7,
    ) -> None:
        self.root = Path(data_dir)
        self.library_dir = self.root / "library"
        self.trash_dir = self.root / "trash"
        self.index_path = self.root / "index.json"
        self.max_images = max(0, int(max_images))
        self.max_file_mb = max(1, int(max_file_mb))
        self.max_tags = max(1, int(max_tags))
        self.trash_retention_days = max(1, int(trash_retention_days))
        self._lock = threading.RLock()
        self.entries: dict[str, ImageEntry] = {}

        self.root.mkdir(parents=True, exist_ok=True)
        self.library_dir.mkdir(parents=True, exist_ok=True)
        self.trash_dir.mkdir(parents=True, exist_ok=True)
        self._load_index()
        self.purge_trash()

    # ------------------------------------------------------------------ paths
    @property
    def max_bytes(self) -> int:
        return self.max_file_mb * 1024 * 1024

    def update_limits(
        self,
        *,
        max_images: int | None = None,
        max_file_mb: int | None = None,
        max_tags: int | None = None,
        trash_retention_days: int | None = None,
    ) -> None:
        with self._lock:
            if max_images is not None:
                self.max_images = max(0, int(max_images))
            if max_file_mb is not None:
                self.max_file_mb = max(1, int(max_file_mb))
            if max_tags is not None:
                self.max_tags = max(1, int(max_tags))
            if trash_retention_days is not None:
                self.trash_retention_days = max(1, int(trash_retention_days))

    def entry_path(self, entry: ImageEntry) -> Path:
        return self._safe_library_path(entry.file)

    def _safe_library_path(self, filename: str) -> Path:
        if not str(filename or "").strip():
            raise ImageLibraryError("图片文件名为空。")
        path = (self.library_dir / filename).resolve()
        try:
            path.relative_to(self.library_dir.resolve())
        except ValueError as exc:
            raise ImageLibraryError("图片路径非法。") from exc
        return path

    # ------------------------------------------------------------------ index
    def _load_index(self) -> None:
        with self._lock:
            if not self.index_path.is_file():
                return
            try:
                raw = json.loads(self.index_path.read_text(encoding="utf-8"))
            except Exception:
                backup = self.index_path.with_name(
                    f"index.corrupt-{int(time.time())}.json"
                )
                try:
                    os.replace(self.index_path, backup)
                except OSError:
                    pass
                self.entries = {}
                return

            entries = raw.get("entries", {}) if isinstance(raw, dict) else {}
            if isinstance(entries, list):
                entries = {str(item.get("id")): item for item in entries if isinstance(item, dict)}
            for key, value in entries.items():
                if not isinstance(value, dict):
                    continue
                try:
                    entry = ImageEntry.from_dict(value)
                except Exception:
                    continue
                if not entry.id:
                    entry.id = str(key)
                self.entries[entry.id] = entry

    def _save_index_locked(self) -> None:
        payload = {
            "version": INDEX_VERSION,
            "updated_at": time.time(),
            "entries": {entry.id: entry.to_dict() for entry in self.entries.values()},
        }
        self._write_json(self.index_path, payload)

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)

    def _write_bytes(self, path: Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)

    # ------------------------------------------------------------------- add
    def add_bytes(
        self,
        data: bytes,
        *,
        tags: Iterable[str] = (),
        caption: str = "",
        source: str = "upload",
        uploader_id: str = "",
        uploader_name: str = "",
    ) -> AddResult:
        if not data:
            raise UnsupportedImage("图片内容为空。")
        if len(data) > self.max_bytes:
            raise ImageTooLarge(
                f"图片超过 {self.max_file_mb} MB 限制（当前 {human_size(len(data))}）。"
            )
        extension = self._detect_image(data)
        if extension is None:
            raise UnsupportedImage("仅支持 JPG、PNG、GIF、WebP、BMP 格式的图片。")

        normalized_tags = clean_tags(tags, max_tags=self.max_tags)
        clean_caption_text = re.sub(r"\s+", " ", str(caption or "")).strip()[:MAX_CAPTION_LEN]
        digest = hashlib.sha256(data).hexdigest()

        with self._lock:
            for entry in self.entries.values():
                if (
                    entry.sha256
                    and entry.sha256 == digest
                    and self._entry_file_exists(entry)
                ):
                    changed = False
                    for tag in normalized_tags:
                        if tag not in entry.tags and len(entry.tags) < self.max_tags:
                            entry.tags.append(tag)
                            changed = True
                    if clean_caption_text and not entry.caption:
                        entry.caption = clean_caption_text
                        changed = True
                    if changed:
                        entry.updated_at = time.time()
                        self._save_index_locked()
                    return AddResult(entry=entry, created=False, changed=changed)

            self._ensure_capacity_locked(reserve=1)
            entry_id = self._new_id_locked()
            filename = f"{entry_id}.{extension}"
            destination = self._safe_library_path(filename)
            self._write_bytes(destination, data)
            width, height = self._dimensions(data)
            entry = ImageEntry(
                id=entry_id,
                file=filename,
                sha256=digest,
                tags=normalized_tags,
                caption=clean_caption_text,
                source=str(source or "upload")[:24],
                uploader_id=str(uploader_id or "")[:96],
                uploader_name=str(uploader_name or "")[:96],
                size=len(data),
                width=width,
                height=height,
            )
            self.entries[entry_id] = entry
            try:
                self._save_index_locked()
            except Exception:
                self.entries.pop(entry_id, None)
                try:
                    destination.unlink()
                except OSError:
                    pass
                raise
            return AddResult(entry=entry, created=True, changed=True)

    def add_from_path(
        self,
        path: str | Path,
        *,
        tags: Iterable[str] = (),
        caption: str = "",
        source: str = "upload",
        uploader_id: str = "",
        uploader_name: str = "",
    ) -> AddResult:
        source_path = Path(path)
        if not source_path.is_file():
            raise UnsupportedImage("没有找到可读取的图片文件。")
        try:
            if source_path.stat().st_size > self.max_bytes:
                raise ImageTooLarge(f"图片超过 {self.max_file_mb} MB 限制。")
            data = source_path.read_bytes()
        except ImageLibraryError:
            raise
        except OSError as exc:
            raise UnsupportedImage(f"读取图片失败：{exc}") from exc
        return self.add_bytes(
            data,
            tags=tags,
            caption=caption,
            source=source,
            uploader_id=uploader_id,
            uploader_name=uploader_name,
        )

    def _new_id_locked(self) -> str:
        while True:
            entry_id = f"img_{secrets.token_hex(4)}"
            if entry_id not in self.entries and not self._safe_library_path(
                f"{entry_id}.png"
            ).exists():
                return entry_id

    def _ensure_capacity_locked(self, reserve: int = 1) -> int:
        if self.max_images <= 0:
            return 0
        removed = 0
        now = time.time()
        while len(self.entries) + reserve > self.max_images:
            candidates = list(self.entries.values())
            if not candidates:
                break

            def victim_key(entry: ImageEntry) -> tuple:
                # Newly uploaded images get a short grace period. Among old
                # images, low usage / negative feedback is removed first.
                protected = 1 if now - entry.created_at < 600 else 0
                value = entry.uses + entry.likes * 2 - entry.dislikes * 2
                return (protected, value, entry.last_used_at, entry.created_at)

            victim = min(candidates, key=victim_key)
            try:
                self._trash_locked(victim, reason="capacity")
            except Exception:
                break
            removed += 1

        if len(self.entries) + reserve > self.max_images:
            raise ImageLibraryError(
                f"图库已达到 {self.max_images} 张上限，且自动清理失败。"
            )
        return removed

    # ------------------------------------------------------------------ query
    def get(self, entry_id: str) -> ImageEntry:
        with self._lock:
            return self._get_locked(entry_id)

    def _get_locked(self, entry_id: str) -> ImageEntry:
        key = str(entry_id or "").strip().lstrip("#").lower()
        if not key:
            raise ImageNotFound("请提供图片 ID。")
        if key in self.entries:
            return self.entries[key]
        if f"img_{key}" in self.entries:
            return self.entries[f"img_{key}"]
        matches = [entry for entry in self.entries.values() if entry.id.startswith(key)]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ImageNotFound(f"ID 前缀 {key} 匹配到多张图片，请写完整 ID。")
        raise ImageNotFound(f"没有找到图片 #{short_id(key)}。")

    def list_page(
        self, page: int = 1, page_size: int = 8
    ) -> tuple[list[ImageEntry], int, int]:
        page = max(1, int(page or 1))
        page_size = max(1, min(50, int(page_size or 8)))
        with self._lock:
            entries = sorted(
                self.entries.values(), key=lambda item: item.created_at, reverse=True
            )
            total = len(entries)
            pages = max(1, (total + page_size - 1) // page_size)
            page = min(page, pages)
            start = (page - 1) * page_size
            return entries[start : start + page_size], total, pages

    def search(
        self,
        query: str,
        *,
        limit: int = 20,
        include_disabled: bool = True,
    ) -> list[tuple[ImageEntry, float]]:
        query_text = normalize_text(query)
        tokens = set(tokenize(query_text))
        with self._lock:
            entries = list(self.entries.values())
        results: list[tuple[ImageEntry, float]] = []
        for entry in entries:
            if not include_disabled and not entry.enabled:
                continue
            if not self._entry_file_exists(entry):
                continue
            if not query_text:
                score = 0.01
            else:
                score = self.match_score(entry, query_text, tokens)
                haystack = normalize_text(" ".join(entry.tags) + " " + entry.caption)
                if query_text in haystack:
                    score = max(score, 0.5)
            if score > 0:
                results.append((entry, score))
        results.sort(
            key=lambda item: (-item[1], -item[0].likes, -item[0].created_at)
        )
        return results[: max(1, int(limit))]

    def match_score(
        self, entry: ImageEntry, query_text: str, tokens: set[str] | None = None
    ) -> float:
        query_text = normalize_text(query_text)
        if not query_text:
            return 0.0
        tokens = set(tokens if tokens is not None else tokenize(query_text))
        best = 0.0

        joined_tags = normalize_text(" ".join(entry.tags))
        if query_text in joined_tags:
            best = max(best, 0.8)

        for tag in entry.tags:
            tag_text = normalize_text(tag)
            if not tag_text:
                continue
            if tag_text in tokens:
                best = max(best, 1.0)
            elif len(tag_text) >= 2 and tag_text in query_text:
                best = max(best, 0.92)
            elif len(tag_text) == 1 and tag_text in query_text:
                best = max(best, 0.8)

        caption = normalize_text(entry.caption)
        if caption:
            if len(caption) >= 2 and caption in query_text:
                best = max(best, 0.9)
            elif len(query_text) >= 2 and query_text in caption:
                best = max(best, 0.72)

        entry_tokens = set(tokenize(" ".join(entry.tags) + " " + entry.caption))
        overlap = tokens & entry_tokens
        if len(overlap) >= 2:
            best = max(best, min(0.88, 0.45 + 0.1 * len(overlap)))

        # Last-resort fuzzy match for Chinese phrases with a shared substring,
        # e.g. tag "一只橘猫" should match "来张橘猫".
        for candidate in (*entry.tags, entry.caption):
            candidate_text = normalize_text(candidate)
            if len(candidate_text) < 2:
                continue
            common = _longest_common_substring(query_text, candidate_text)
            if common >= 2:
                best = max(best, min(0.9, 0.75 + 0.03 * (common - 2)))
        return best

    def find_best(
        self,
        text: str,
        *,
        threshold: float = 0.75,
        exclude_ids: Iterable[str] = (),
    ) -> tuple[ImageEntry, float] | None:
        query_text = normalize_text(text)
        if not query_text:
            return None
        tokens = set(tokenize(query_text))
        excluded = set(exclude_ids)
        now = time.time()
        with self._lock:
            entries = list(self.entries.values())
        candidates: list[tuple[float, ImageEntry]] = []
        for entry in entries:
            if not entry.enabled or entry.id in excluded:
                continue
            if entry.penalty_until > now:
                continue
            if not self._entry_file_exists(entry):
                continue
            score = self.match_score(entry, query_text, tokens)
            if score >= threshold:
                candidates.append((score, entry))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], -item[1].likes, -item[1].created_at))
        best_score = candidates[0][0]
        pool = [item for item in candidates if item[0] >= best_score - 0.02][:5]
        total = sum(item[0] for item in pool)
        point = random.uniform(0, total)
        running = 0.0
        for score, entry in pool:
            running += score
            if point <= running:
                return entry, score
        return pool[-1][1], pool[-1][0]

    def random_entry(self, tag: str = "") -> ImageEntry | None:
        tag_texts = [normalize_text(item) for item in split_tags(tag)]
        tag_texts = [item for item in tag_texts if item]
        with self._lock:
            entries = [
                entry
                for entry in self.entries.values()
                if entry.enabled and self._entry_file_exists(entry)
            ]
        if tag_texts:
            filtered = []
            for entry in entries:
                haystack = normalize_text(" ".join(entry.tags) + " " + entry.caption)
                if any(item in haystack for item in tag_texts):
                    filtered.append(entry)
            entries = filtered
        if not entries:
            return None
        weights = [1.0 / (1.0 + max(0, entry.uses)) + max(0, entry.likes) * 0.1 for entry in entries]
        return random.choices(entries, weights=weights, k=1)[0]

    def record_use(self, entry_id: str) -> ImageEntry:
        with self._lock:
            entry = self._get_locked(entry_id)
            entry.uses += 1
            entry.last_used_at = time.time()
            self._save_index_locked()
            return entry

    # ------------------------------------------------------------------ mutate
    def set_tags(self, entry_id: str, tags: Iterable[str]) -> ImageEntry:
        normalized = clean_tags(tags, max_tags=self.max_tags)
        if not normalized:
            raise ImageLibraryError("至少保留一个标签。")
        with self._lock:
            entry = self._get_locked(entry_id)
            entry.tags = normalized
            entry.updated_at = time.time()
            self._save_index_locked()
            return entry

    def add_tags(self, entry_id: str, tags: Iterable[str]) -> tuple[ImageEntry, int]:
        normalized = clean_tags(tags, max_tags=self.max_tags)
        with self._lock:
            entry = self._get_locked(entry_id)
            added = 0
            for tag in normalized:
                if tag not in entry.tags and len(entry.tags) < self.max_tags:
                    entry.tags.append(tag)
                    added += 1
            if added:
                entry.updated_at = time.time()
                self._save_index_locked()
            return entry, added

    def remove_tags(self, entry_id: str, tags: Iterable[str]) -> tuple[ImageEntry, int]:
        targets = set(clean_tags(tags, max_tags=self.max_tags))
        with self._lock:
            entry = self._get_locked(entry_id)
            before = len(entry.tags)
            entry.tags = [tag for tag in entry.tags if tag not in targets]
            removed = before - len(entry.tags)
            if removed:
                entry.updated_at = time.time()
                self._save_index_locked()
            return entry, removed

    def set_caption(self, entry_id: str, caption: str) -> ImageEntry:
        with self._lock:
            entry = self._get_locked(entry_id)
            entry.caption = re.sub(r"\s+", " ", str(caption or "")).strip()[:MAX_CAPTION_LEN]
            entry.updated_at = time.time()
            self._save_index_locked()
            return entry

    def set_enabled(self, entry_id: str, enabled: bool) -> ImageEntry:
        with self._lock:
            entry = self._get_locked(entry_id)
            entry.enabled = bool(enabled)
            entry.updated_at = time.time()
            self._save_index_locked()
            return entry

    def feedback(self, entry_id: str, positive: bool) -> ImageEntry:
        with self._lock:
            entry = self._get_locked(entry_id)
            if positive:
                entry.likes += 1
                entry.penalty_until = 0.0
            else:
                entry.dislikes += 1
                entry.penalty_until = time.time() + 3600
            entry.updated_at = time.time()
            self._save_index_locked()
            return entry

    def delete(self, entry_id: str, reason: str = "delete") -> tuple[ImageEntry, str]:
        with self._lock:
            entry = self._get_locked(entry_id)
            trash_id = self._trash_locked(entry, reason=reason)
            self._save_index_locked()
            return entry, trash_id

    def clear(self) -> int:
        with self._lock:
            entries = list(self.entries.values())
            removed = 0
            for entry in entries:
                try:
                    self._trash_locked(entry, reason="clear")
                    removed += 1
                except Exception:
                    continue
            if removed:
                self._save_index_locked()
            return removed

    def enforce_capacity(self) -> int:
        """Trim the library to max_images and return how many were moved out."""
        with self._lock:
            removed = self._ensure_capacity_locked(0)
            if removed:
                self._save_index_locked()
            return removed

    # ------------------------------------------------------------------ trash
    def _trash_locked(self, entry: ImageEntry, reason: str) -> str:
        stamp = int(time.time())
        trash_id = f"{stamp}-{entry.id}-{secrets.token_hex(2)}"
        target_dir = self.trash_dir / trash_id
        target_dir.mkdir(parents=True, exist_ok=False)
        try:
            source = self.entry_path(entry)
        except Exception:
            shutil.rmtree(target_dir, ignore_errors=True)
            raise
        moved = False
        try:
            if source.is_file():
                shutil.move(str(source), str(target_dir / source.name))
                moved = True
            elif source.exists():
                raise ImageLibraryError("图片路径不是普通文件，已拒绝移入回收站。")
            meta = {
                "trash_id": trash_id,
                "deleted_at": time.time(),
                "reason": reason,
                "entry": entry.to_dict(),
            }
            self._write_json(target_dir / "meta.json", meta)
        except Exception:
            if moved:
                try:
                    shutil.move(str(target_dir / source.name), str(source))
                except OSError:
                    pass
            shutil.rmtree(target_dir, ignore_errors=True)
            raise
        self.entries.pop(entry.id, None)
        return trash_id

    def list_trash(self, limit: int = 50) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        if not self.trash_dir.is_dir():
            return records
        for item in self.trash_dir.iterdir():
            if not item.is_dir() or item.name.startswith("_"):
                continue
            meta_path = item / "meta.json"
            if not meta_path.is_file():
                continue
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            entry = meta.get("entry", {}) if isinstance(meta, dict) else {}
            try:
                deleted_at = float(meta.get("deleted_at", 0) or 0)
            except (TypeError, ValueError):
                deleted_at = 0.0
            try:
                size = int(entry.get("size", 0) or 0)
            except (TypeError, ValueError):
                size = 0
            tags = entry.get("tags") or []
            if not isinstance(tags, list):
                tags = [tags]
            tags = [str(tag) for tag in tags if str(tag).strip()]
            records.append(
                {
                    "trash_id": item.name,
                    "entry_id": str(entry.get("id", "")),
                    "caption": str(entry.get("caption", "")),
                    "tags": tags,
                    "deleted_at": deleted_at,
                    "reason": str(meta.get("reason", "")),
                    "size": size,
                }
            )
        records.sort(key=lambda item: item["deleted_at"], reverse=True)
        return records[: max(1, int(limit))]

    def find_trash(self, trash_id: str) -> Path | None:
        key = (
            str(trash_id or "").strip().replace("\\", "/").split("/")[-1].lower()
        )
        if not key or key in {".", ".."}:
            return None
        exact = self.trash_dir / key
        if exact.is_dir():
            return exact
        if not self.trash_dir.is_dir():
            return None
        candidates: list[Path] = []
        for item in self.trash_dir.iterdir():
            if not item.is_dir() or item.name.startswith("_"):
                continue
            if item.name.endswith(f"-{key}") or key in item.name:
                candidates.append(item)
                continue
            meta_path = item / "meta.json"
            if not meta_path.is_file():
                continue
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                entry_id = str(meta.get("entry", {}).get("id", ""))
            except Exception:
                continue
            if entry_id == key or entry_id.startswith(key) or short_id(entry_id) == key:
                candidates.append(item)
        candidates.sort(key=lambda item: item.name, reverse=True)
        return candidates[0] if candidates else None

    def restore(self, trash_id: str) -> ImageEntry:
        with self._lock:
            target_dir = self.find_trash(trash_id)
            if target_dir is None:
                raise ImageNotFound("回收站中没有找到这条记录。")
            meta_path = target_dir / "meta.json"
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                entry = ImageEntry.from_dict(meta["entry"])
            except Exception as exc:
                raise ImageLibraryError("回收站记录已损坏。") from exc

            files = [
                item for item in target_dir.iterdir() if item.is_file() and item.name != "meta.json"
            ]
            if not files:
                raise ImageLibraryError("回收站中的图片文件已丢失。")
            source = files[0]

            suffix = Path(entry.file).suffix or source.suffix
            entry.file = f"{entry.id}{suffix}"
            destination = self._safe_library_path(entry.file)
            if entry.id in self.entries or destination.exists():
                entry.id = self._new_id_locked()
                entry.file = f"{entry.id}{suffix}"
                destination = self._safe_library_path(entry.file)
            shutil.move(str(source), str(destination))
            entry.updated_at = time.time()
            entry.enabled = True
            entry.penalty_until = 0.0
            self.entries[entry.id] = entry
            self._save_index_locked()
            shutil.rmtree(target_dir, ignore_errors=True)
            return entry

    def purge_trash(self, days: int | None = None) -> int:
        retention = self.trash_retention_days if days is None else max(1, int(days))
        cutoff = time.time() - retention * 86400
        removed = 0
        if not self.trash_dir.is_dir():
            return 0
        for item in self.trash_dir.iterdir():
            if not item.is_dir():
                continue
            if item.name.startswith("_"):
                # Orphan directories are kept for the same retention window.
                try:
                    if item.stat().st_mtime < cutoff:
                        shutil.rmtree(item, ignore_errors=True)
                        removed += 1
                except OSError:
                    pass
                continue
            meta_path = item / "meta.json"
            deleted_at = item.stat().st_mtime
            if meta_path.is_file():
                try:
                    deleted_at = float(
                        json.loads(meta_path.read_text(encoding="utf-8")).get("deleted_at", deleted_at)
                    )
                except Exception:
                    pass
            if deleted_at < cutoff:
                shutil.rmtree(item, ignore_errors=True)
                removed += 1
        return removed

    def empty_trash(self) -> int:
        removed = 0
        if not self.trash_dir.is_dir():
            return 0
        for item in self.trash_dir.iterdir():
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
                removed += 1
        return removed

    # ------------------------------------------------------------------ repair
    def repair(self) -> dict[str, Any]:
        missing_removed = 0
        orphans_moved = 0
        orphan_dir = ""
        with self._lock:
            referenced: set[str] = set()
            for entry in list(self.entries.values()):
                try:
                    path = self.entry_path(entry)
                except ImageLibraryError:
                    self.entries.pop(entry.id, None)
                    missing_removed += 1
                    continue
                if not path.is_file():
                    self.entries.pop(entry.id, None)
                    missing_removed += 1
                    continue
                referenced.add(path.name)

            orphan_files = [
                item
                for item in self.library_dir.iterdir()
                if item.is_file()
                and item.name not in referenced
                and not item.name.endswith(".tmp")
            ]
            if orphan_files:
                orphan_dir = str(
                    self.trash_dir / f"_orphans-{int(time.time())}"
                )
                Path(orphan_dir).mkdir(parents=True, exist_ok=True)
                for item in orphan_files:
                    try:
                        shutil.move(str(item), str(Path(orphan_dir) / item.name))
                        orphans_moved += 1
                    except OSError:
                        continue
            for item in self.library_dir.glob("*.tmp"):
                try:
                    item.unlink()
                except OSError:
                    pass
            if missing_removed:
                self._save_index_locked()
        return {
            "missing_removed": missing_removed,
            "orphans_moved": orphans_moved,
            "orphan_dir": orphan_dir,
        }

    # ------------------------------------------------------------------ stats
    def stats(self) -> dict[str, Any]:
        with self._lock:
            entries = list(self.entries.values())
            trash = self.list_trash(limit=1000)
        tag_counter: Counter[str] = Counter()
        total_size = 0
        enabled = 0
        for entry in entries:
            tag_counter.update(entry.tags)
            total_size += entry.size
            if entry.enabled:
                enabled += 1
        return {
            "total": len(entries),
            "enabled": enabled,
            "disabled": len(entries) - enabled,
            "total_size": total_size,
            "trash": len(trash),
            "top_tags": tag_counter.most_common(10),
            "uses": sum(entry.uses for entry in entries),
            "likes": sum(entry.likes for entry in entries),
            "dislikes": sum(entry.dislikes for entry in entries),
            "oldest": min((entry.created_at for entry in entries), default=0),
            "newest": max((entry.created_at for entry in entries), default=0),
        }

    def all_tags(self, limit: int = 30) -> list[tuple[str, int]]:
        with self._lock:
            counter: Counter[str] = Counter()
            for entry in self.entries.values():
                counter.update(entry.tags)
        return counter.most_common(max(1, int(limit)))

    def iter_entries(self) -> list[ImageEntry]:
        with self._lock:
            return list(self.entries.values())

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _detect_image(data: bytes) -> str | None:
        for signature, extension in _IMAGE_SIGNATURES:
            if data.startswith(signature):
                return extension
        if (
            len(data) >= 12
            and data[:4] == b"RIFF"
            and data[8:12] == b"WEBP"
        ):
            return "webp"
        return None

    @staticmethod
    def _dimensions(data: bytes) -> tuple[int, int]:
        if PILImage is None:
            return 0, 0
        try:
            import io

            with PILImage.open(io.BytesIO(data)) as image:
                return int(image.width), int(image.height)
        except Exception:
            return 0, 0

    def _entry_file_exists(self, entry: ImageEntry) -> bool:
        try:
            return self.entry_path(entry).is_file()
        except ImageLibraryError:
            return False
