"""AstrBot 智能图库插件。

跨平台图片库：聊天上传、标签检索、随机/自动发图、自学习与自管理。
所有发送都使用 AstrBot 统一消息链，因此不依赖任何单一平台适配器。
"""

from __future__ import annotations

import asyncio
import base64
import importlib.util
import ipaddress
import os
import re
import socket
import sys
import tempfile
import time
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import astrbot.api.message_components as Comp
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star

try:
    from astrbot.core.utils.astrbot_path import get_astrbot_data_path
except Exception:  # pragma: no cover - very old AstrBot fallback

    def get_astrbot_data_path() -> str:
        return str(Path.cwd() / "data")


def _load_local_core():
    """Load core.py by file path.

    AstrBot may install a ZIP into a temporary/renamed directory, so relative
    imports such as "from .core import ..." are not reliable. Loading the file
    explicitly works both when main.py is imported as a package module and when
    it is imported as a top-level module.
    """
    module_name = f"{__name__}_core"
    core_path = Path(__file__).resolve().with_name("core.py")
    if not core_path.is_file():
        raise ImportError(f"找不到插件核心文件：{core_path}")
    spec = importlib.util.spec_from_file_location(module_name, core_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载插件核心文件：{core_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


_core = _load_local_core()
DEFAULT_TAG = _core.DEFAULT_TAG
ImageEntry = _core.ImageEntry
ImageLibrary = _core.ImageLibrary
ImageLibraryError = _core.ImageLibraryError
ImageTooLarge = _core.ImageTooLarge
UnsupportedImage = _core.UnsupportedImage
clean_tags = _core.clean_tags
extract_hashtags = _core.extract_hashtags
extract_keywords = _core.extract_keywords
feedback_signal = _core.feedback_signal
human_size = _core.human_size
normalize_text = _core.normalize_text
should_skip_auto_send = _core.should_skip_auto_send
should_skip_learning = _core.should_skip_learning
short_id = _core.short_id
split_caption = _core.split_caption
split_tags = _core.split_tags


PLUGIN_NAME = "astrbot_plugin_smart_image"
COMMAND_NAMES = {"图库", "img", "image"}

DEFAULT_CONFIG: dict[str, Any] = {
    "auto_learn_default": False,
    "auto_send_default": False,
    "allow_member_upload": True,
    "allow_member_delete_own": True,
    "allow_member_manage_own": True,
    "allow_member_url_import": False,
    "allow_private_url": False,
    "extra_admins": [],
    "max_file_mb": 10,
    "max_images": 2000,
    "max_tags": 12,
    "page_size": 8,
    "search_limit": 12,
    "search_preview": 3,
    "auto_send_cooldown": 90,
    "auto_send_daily_limit": 30,
    "auto_send_min_score": 0.75,
    "auto_send_require_wake": True,
    "auto_send_block_llm": True,
    "feedback_learning": True,
    "show_tags": False,
    "use_file_service": False,
    "public_base_url": "",
    "trash_retention_days": 7,
}

SUB_ALIASES = {
    "帮助": "help",
    "help": "help",
    "菜单": "help",
    "?": "help",
    "？": "help",
    "上传": "upload",
    "add": "upload",
    "添加": "upload",
    "存图": "upload",
    "链接": "url",
    "url": "url",
    "导入": "url",
    "随机": "random",
    "random": "random",
    "来一张": "random",
    "来图": "random",
    "搜索": "search",
    "search": "search",
    "找": "search",
    "查": "search",
    "列表": "list",
    "list": "list",
    "ls": "list",
    "详情": "info",
    "info": "info",
    "查看": "info",
    "改标签": "tag",
    "tag": "tag",
    "set": "tag",
    "加标签": "addtag",
    "addtag": "addtag",
    "删标签": "deltag",
    "deltag": "deltag",
    "removetag": "deltag",
    "删除": "delete",
    "del": "delete",
    "delete": "delete",
    "移除": "delete",
    "启用": "enable",
    "enable": "enable",
    "on": "enable",
    "禁用": "disable",
    "disable": "disable",
    "off": "disable",
    "统计": "stats",
    "stats": "stats",
    "状态": "stats",
    "学习": "learn",
    "learn": "learn",
    "学习模式": "learnmode",
    "learnmode": "learnmode",
    "自动": "auto",
    "auto": "auto",
    "自动发送": "auto",
    "赞": "like",
    "like": "like",
    "喜欢": "like",
    "踩": "dislike",
    "dislike": "dislike",
    "不喜欢": "dislike",
    "回收站": "trash",
    "trash": "trash",
    "恢复": "restore",
    "restore": "restore",
    "清空回收站": "emptytrash",
    "emptytrash": "emptytrash",
    "修复": "repair",
    "repair": "repair",
    "清理": "prune",
    "prune": "prune",
    "清空": "clear",
    "clear": "clear",
}

HELP_TEXT = """🖼️ 智能图库 · 跨平台图片库

【上传】
/图库 上传 <标签...> [| 描述]
  附带图片，或引用一条含图片的消息
/图库 链接 <URL> <标签...> [| 描述]
/图库 学习 <标签...> [| 描述]
/图库 随机 [标签]
/图库 搜索 <关键词>
/图库 列表 [页码]
/图库 详情 <ID>

【整理】
/图库 改标签 <ID> <标签...> [| 描述]
/图库 加标签 <ID> <标签...>
/图库 删标签 <ID> <标签...>
/图库 删除 <ID>
/图库 启用 / 禁用 <ID>

【自学习】
/图库 学习模式 开|关
  开启后，本会话中带文字说明的图片会自动入库
/图库 自动 开|关
  开启后，识别到标签会主动发图
/图库 赞 / 踩 [ID]
  不写 ID 时评价最近自动发送的图片

【管理】
/图库 统计
/图库 回收站 [页码]
/图库 恢复 <ID>
/图库 修复
/图库 清理
/图库 清空 confirm

标签用空格或逗号分隔；竖线后的文字会作为描述一同保存。
群聊中自动发图默认需要 @机器人 或唤醒词，避免刷屏。"""


class SmartImagePlugin(Star):
    """智能图库：上传、检索、自动发送、自学习与自管理图片。"""

    def __init__(self, context: Context, config: dict | None = None) -> None:
        super().__init__(context)
        if not hasattr(self, "logger"):
            import logging

            self.logger = logging.getLogger(PLUGIN_NAME)
        self.config: dict[str, Any] = config or {}
        self._lock = asyncio.Lock()
        self.data_dir = Path(get_astrbot_data_path()) / "plugin_data" / PLUGIN_NAME
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.data_dir / "state.json"
        self._temp_paths: set[Path] = set()

        self.lib = ImageLibrary(
            self.data_dir,
            max_images=self._cfg_int("max_images", 2000),
            max_file_mb=self._cfg_int("max_file_mb", 10),
            max_tags=self._cfg_int("max_tags", 12),
            trash_retention_days=self._cfg_int("trash_retention_days", 7),
        )
        self.state = self._load_state()
        self._prune_state()
        self.logger.info(
            "智能图库已加载：%s 张图片，数据目录 %s",
            len(self.lib.entries),
            self.data_dir,
        )

    # ------------------------------------------------------------------ config
    def _cfg(self, key: str, default: Any = None) -> Any:
        if key in self.config:
            return self.config.get(key)
        return DEFAULT_CONFIG.get(key, default)

    def _cfg_bool(self, key: str, default: bool = False) -> bool:
        value = self._cfg(key, default)
        if isinstance(value, bool):
            return value
        return normalize_text(value) in {"1", "true", "yes", "on", "开", "开启"}

    def _cfg_int(self, key: str, default: int) -> int:
        try:
            return int(self._cfg(key, default))
        except (TypeError, ValueError):
            return int(default)

    def _cfg_float(self, key: str, default: float) -> float:
        try:
            return float(self._cfg(key, default))
        except (TypeError, ValueError):
            return float(default)

    def _sync_limits(self) -> None:
        self.lib.update_limits(
            max_images=self._cfg_int("max_images", 2000),
            max_file_mb=self._cfg_int("max_file_mb", 10),
            max_tags=self._cfg_int("max_tags", 12),
            trash_retention_days=self._cfg_int("trash_retention_days", 7),
        )

    def _extra_admin_ids(self) -> set[str]:
        raw = self._cfg("extra_admins", [])
        if isinstance(raw, str):
            raw = re.split(r"[\s,，、]+", raw)
        if not isinstance(raw, (list, tuple, set)):
            return set()
        return {str(item).strip() for item in raw if str(item).strip()}

    def _is_admin(self, event: AstrMessageEvent) -> bool:
        try:
            if event.is_admin():
                return True
        except Exception:
            pass
        sender = str(event.get_sender_id() or "").strip()
        return bool(sender and sender in self._extra_admin_ids())

    def _can_manage(self, event: AstrMessageEvent, entry: ImageEntry, *, delete: bool = False) -> bool:
        if self._is_admin(event):
            return True
        key = "allow_member_delete_own" if delete else "allow_member_manage_own"
        if not self._cfg_bool(key, True):
            return False
        sender = str(event.get_sender_id() or "").strip()
        return bool(sender and entry.uploader_id and sender == entry.uploader_id)

    # -------------------------------------------------------------------- state
    def _load_state(self) -> dict[str, Any]:
        if not self.state_path.is_file():
            return {"version": 1, "sessions": {}}
        try:
            import json

            raw = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("state is not an object")
            if not isinstance(raw.get("sessions"), dict):
                raw["sessions"] = {}
            raw.setdefault("version", 1)
            return raw
        except Exception:
            backup = self.state_path.with_name(
                f"state.corrupt-{int(time.time())}.json"
            )
            try:
                os.replace(self.state_path, backup)
            except OSError:
                pass
            return {"version": 1, "sessions": {}}

    def _save_state(self) -> None:
        import json

        sessions = self.state.get("sessions", {})
        if not isinstance(sessions, dict):
            sessions = {}
            self.state["sessions"] = sessions
        if len(sessions) > 5000:
            def session_age(item: tuple[str, Any]) -> float:
                value = item[1]
                if not isinstance(value, dict):
                    return 0.0
                try:
                    return float(value.get("updated_at", 0) or 0)
                except (TypeError, ValueError):
                    return 0.0

            ordered = sorted(sessions.items(), key=session_age, reverse=True)[:5000]
            self.state["sessions"] = dict(ordered)
        temporary = self.state_path.with_name(self.state_path.name + ".tmp")
        temporary.parent.mkdir(parents=True, exist_ok=True)
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(self.state, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, self.state_path)

    def _prune_state(self) -> None:
        sessions = self.state.get("sessions", {})
        if not isinstance(sessions, dict):
            self.state["sessions"] = {}
            return
        cutoff = time.time() - 90 * 86400
        for key, value in list(sessions.items()):
            if not isinstance(value, dict):
                sessions.pop(key, None)
                continue
            try:
                updated_at = float(value.get("updated_at", 0) or 0)
            except (TypeError, ValueError):
                updated_at = 0.0
            if updated_at < cutoff:
                sessions.pop(key, None)

    def _state_for(self, event: AstrMessageEvent) -> dict[str, Any]:
        sessions = self.state.setdefault("sessions", {})
        if not isinstance(sessions, dict):
            sessions = {}
            self.state["sessions"] = sessions
        key = str(event.unified_msg_origin or event.session_id or "unknown")
        session = sessions.get(key)
        if not isinstance(session, dict):
            session = {}
            sessions[key] = session
        session.setdefault("learn", self._cfg_bool("auto_learn_default", False))
        session.setdefault("auto", self._cfg_bool("auto_send_default", False))
        session.setdefault("last_auto_at", 0.0)
        session.setdefault("auto_times", [])
        session.setdefault("recent", [])
        session.setdefault("pending", None)
        session["updated_at"] = time.time()
        return session

    # ------------------------------------------------------------------ command
    @filter.command("图库", alias={"img", "image"})
    async def image_library(self, event: AstrMessageEvent):
        """智能图库：上传、搜索、随机发送、学习与管理图片。"""
        results: list[Any] = []
        try:
            results = await self._dispatch(event)
        except ImageLibraryError as exc:
            results = [event.plain_result(f"❌ {exc}")]
        except Exception as exc:
            self.logger.exception("图库指令执行失败")
            results = [event.plain_result(f"❌ 图库操作失败：{exc}")]
        try:
            for result in results:
                if result is not None:
                    yield result
        finally:
            event.stop_event()

    async def _dispatch(self, event: AstrMessageEvent) -> list[Any]:
        self._sync_limits()
        body = self._strip_command(event.message_str)
        if not body:
            return [event.plain_result(HELP_TEXT)]
        parts = re.split(r"\s+", body, maxsplit=1)
        head = parts[0]
        rest = parts[1] if len(parts) > 1 else ""
        canonical = SUB_ALIASES.get(head.lower(), "")
        if not canonical:
            return [
                event.plain_result(
                    f"未知子命令：{head}\n\n{HELP_TEXT}"
                )
            ]
        handler = getattr(self, f"_cmd_{canonical}", None)
        if handler is None:
            return [event.plain_result(HELP_TEXT)]
        return await handler(event, rest.strip())

    @staticmethod
    def _strip_command(text: Any) -> str:
        raw = str(text or "").strip()
        raw = re.sub(r"^[\s/!！.。]+", "", raw)
        if not raw:
            return ""
        parts = re.split(r"\s+", raw, maxsplit=1)
        head = parts[0].split("@", 1)[0].lower()
        if head in COMMAND_NAMES:
            return (parts[1] if len(parts) > 1 else "").strip()
        return raw

    @staticmethod
    def _take_id(text: str) -> tuple[str, str]:
        text = str(text or "").strip()
        if not text:
            raise ImageLibraryError("请提供图片 ID（可只写 # 后面的部分）。")
        parts = text.split(maxsplit=1)
        return parts[0].lstrip("#＃"), (parts[1].strip() if len(parts) > 1 else "")

    @staticmethod
    def _parse_page(text: str) -> int:
        match = re.search(r"\d+", str(text or ""))
        if not match:
            return 1
        return max(1, int(match.group()))

    # ------------------------------------------------------------------ upload
    async def _cmd_upload(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        return await self._do_upload(event, rest, source="upload", label="上传")

    async def _cmd_learn(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        return await self._do_upload(event, rest, source="learned", label="学习")

    async def _do_upload(
        self,
        event: AstrMessageEvent,
        rest: str,
        *,
        source: str,
        label: str,
    ) -> list[Any]:
        if not self._cfg_bool("allow_member_upload", True) and not self._is_admin(event):
            return [event.plain_result("❌ 当前配置只允许管理员上传图片。")]

        images = self._extract_images(event)
        if not images:
            return [
                event.plain_result(
                    "请在这条消息中附带图片，或引用一条含图片的消息。\n"
                    f"用法：/图库 {label} <标签...> [| 描述]"
                )
            ]

        tags_part, caption = split_caption(rest)
        tags = clean_tags(
            split_tags(tags_part) + extract_hashtags(rest),
            max_tags=self._cfg_int("max_tags", 12),
        )
        if not tags and caption:
            tags = extract_keywords(caption, limit=self._cfg_int("max_tags", 12))
        if not tags:
            tags = [DEFAULT_TAG]

        lines: list[str] = []
        for index, component in enumerate(images[:5], start=1):
            try:
                result = await self._save_component(
                    component,
                    tags=tags,
                    caption=caption,
                    source=source,
                    event=event,
                )
            except ImageTooLarge as exc:
                lines.append(f"❌ 第 {index} 张：{exc}")
                continue
            except UnsupportedImage as exc:
                lines.append(f"❌ 第 {index} 张：{exc}")
                continue
            except Exception as exc:
                self.logger.warning("保存图片失败：%s", exc)
                lines.append(f"❌ 第 {index} 张保存失败：{exc}")
                continue

            entry = result.entry
            if result.created:
                lines.append(
                    f"✅ #{short_id(entry.id)} 已入库 · {', '.join(entry.tags)}"
                    f" · {human_size(entry.size)}"
                )
                if caption:
                    lines.append(f"   描述：{caption}")
            else:
                lines.append(
                    f"♻️ 已存在 #{short_id(entry.id)}，已合并标签：{', '.join(entry.tags)}"
                )

        if len(images) > 5:
            lines.append("ℹ️ 单条消息最多处理 5 张图片，其余未保存。")
        if not lines:
            lines.append("❌ 没有图片保存成功。")
        elif not any(line.startswith("✅") or line.startswith("♻️") for line in lines):
            lines.insert(0, "❌ 没有图片保存成功。")
        return [event.plain_result("\n".join(lines))]

    async def _cmd_url(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        if not self._is_admin(event) and not self._cfg_bool("allow_member_url_import", False):
            return [event.plain_result("❌ 链接导入仅限管理员使用。")]

        match = re.search(r"https?://[^\s]+", rest, re.IGNORECASE)
        if not match:
            return [event.plain_result("用法：/图库 链接 <http(s)://...> <标签...> [| 描述]")]
        url = match.group(0).rstrip(".,;，。；）)]}")
        try:
            await self._validate_url(url)
        except Exception as exc:
            return [event.plain_result(f"❌ 链接不可用：{exc}")]

        remaining = (rest[: match.start()] + " " + rest[match.end() :]).strip()
        tags_part, caption = split_caption(remaining)
        tags = clean_tags(
            split_tags(tags_part) + extract_hashtags(remaining),
            max_tags=self._cfg_int("max_tags", 12),
        )
        if not tags and caption:
            tags = extract_keywords(caption, limit=self._cfg_int("max_tags", 12))
        if not tags:
            tags = [DEFAULT_TAG]

        try:
            result = await self._save_component(
                Comp.Image.fromURL(url),
                tags=tags,
                caption=caption,
                source="url",
                event=event,
            )
        except Exception as exc:
            self.logger.warning("链接导入失败：%s", exc)
            return [event.plain_result(f"❌ 链接导入失败：{exc}")]

        entry = result.entry
        if result.created:
            return [
                event.plain_result(
                    f"✅ #{short_id(entry.id)} 已从链接导入 · {', '.join(entry.tags)}"
                    f" · {human_size(entry.size)}"
                )
            ]
        return [
            event.plain_result(
                f"♻️ 该图片已存在：#{short_id(entry.id)}，已合并标签：{', '.join(entry.tags)}"
            )
        ]

    # ------------------------------------------------------------------ lookup
    async def _cmd_random(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry = self.lib.random_entry(rest.strip())
        if entry is None:
            return [event.plain_result("🎲 图库里没有符合条件的图片。先上传几张吧。")]
        try:
            chain: list[Any] = [await self._image_component(entry)]
        except Exception as exc:
            return [event.plain_result(f"❌ 读取图片失败：{exc}")]
        self.lib.record_use(entry.id)
        if self._cfg_bool("show_tags", False):
            chain.append(Comp.Plain("\n" + self._entry_line(entry)))
        return [event.chain_result(chain)]

    async def _cmd_search(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        query = rest.strip()
        if not query:
            return await self._cmd_list(event, "")
        results = self.lib.search(
            query, limit=self._cfg_int("search_limit", 12), include_disabled=True
        )
        if not results:
            return [event.plain_result(f"🔎 没有找到与「{query}」相关的图片。")]

        preview_count = max(1, min(5, self._cfg_int("search_preview", 3)))
        chain: list[Any] = [Comp.Plain(f"🔎 「{query}」找到 {len(results)} 张：")]
        for entry, _score in results[:preview_count]:
            try:
                chain.append(await self._image_component(entry))
                chain.append(Comp.Plain("\n" + self._entry_line(entry)))
            except Exception:
                chain.append(Comp.Plain(f"\n#{short_id(entry.id)}（图片文件缺失）"))
        if len(results) > preview_count:
            chain.append(
                Comp.Plain(
                    f"\n还有 {len(results) - preview_count} 张，可用 /图库 列表 查看全部。"
                )
            )
        return [event.chain_result(chain)]

    async def _cmd_list(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        page = self._parse_page(rest)
        page_size = max(1, self._cfg_int("page_size", 8))
        entries, total, pages = self.lib.list_page(page, page_size)
        page = min(page, pages)
        if total == 0:
            return [
                event.plain_result(
                    "📚 图库还是空的。\n"
                    "发一张图并输入：/图库 上传 猫 橘猫 | 一只睡觉的橘猫"
                )
            ]
        lines = [f"📚 图库列表 · 共 {total} 张 · 第 {page}/{pages} 页"]
        for entry in entries:
            status = "开" if entry.enabled else "停"
            line = f"#{short_id(entry.id)} [{status}] {', '.join(entry.tags) or '无标签'}"
            if entry.caption:
                caption = entry.caption
                if len(caption) > 36:
                    caption = caption[:36] + "…"
                line += f" · {caption}"
            line += f" · 使用 {entry.uses}"
            lines.append(line)
        if pages > 1:
            lines.append("翻页：/图库 列表 2")
        lines.append("查看详情：/图库 详情 <ID>")
        return [event.plain_result("\n".join(lines))]

    async def _cmd_info(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry_id, _ = self._take_id(rest)
        try:
            entry = self.lib.get(entry_id)
        except ImageLibraryError as exc:
            return [event.plain_result(f"❌ {exc}")]
        text = self._entry_details(entry)
        try:
            chain: list[Any] = [Comp.Plain(text), await self._image_component(entry)]
        except Exception:
            chain = [Comp.Plain(text + "\n（图片文件缺失）")]
        return [event.chain_result(chain)]

    # ------------------------------------------------------------------- tags
    async def _cmd_tag(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry_id, remainder = self._take_id(rest)
        if not remainder:
            return [event.plain_result("用法：/图库 改标签 <ID> <标签...> [| 描述]")]
        entry = self.lib.get(entry_id)
        if not self._can_manage(event, entry):
            return [event.plain_result("❌ 只有管理员或图片上传者可以修改标签。")]
        tags_part, caption = split_caption(remainder)
        tags = clean_tags(split_tags(tags_part), max_tags=self._cfg_int("max_tags", 12))
        if not tags:
            return [event.plain_result("❌ 至少保留一个标签。")]
        entry = self.lib.set_tags(entry.id, tags)
        if caption:
            entry = self.lib.set_caption(entry.id, caption)
        return [
            event.plain_result(
                f"✅ #{short_id(entry.id)} 标签已更新：{', '.join(entry.tags)}"
            )
        ]

    async def _cmd_addtag(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry_id, remainder = self._take_id(rest)
        if not remainder:
            return [event.plain_result("用法：/图库 加标签 <ID> <标签...>")]
        entry = self.lib.get(entry_id)
        if not self._can_manage(event, entry):
            return [event.plain_result("❌ 只有管理员或图片上传者可以修改标签。")]
        added_entry, added = self.lib.add_tags(entry.id, split_tags(remainder))
        if not added:
            return [event.plain_result(f"ℹ️ #{short_id(entry.id)} 没有新增标签。")]
        return [
            event.plain_result(
                f"✅ 已添加 {added} 个标签：{', '.join(added_entry.tags)}"
            )
        ]

    async def _cmd_deltag(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry_id, remainder = self._take_id(rest)
        if not remainder:
            return [event.plain_result("用法：/图库 删标签 <ID> <标签...>")]
        entry = self.lib.get(entry_id)
        if not self._can_manage(event, entry):
            return [event.plain_result("❌ 只有管理员或图片上传者可以修改标签。")]
        updated, removed = self.lib.remove_tags(entry.id, split_tags(remainder))
        if not removed:
            return [event.plain_result("ℹ️ 没有匹配到要删除的标签。")]
        return [
            event.plain_result(
                f"✅ 已删除 {removed} 个标签，剩余：{', '.join(updated.tags) or '无'}"
            )
        ]

    async def _cmd_delete(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        entry_id, _ = self._take_id(rest)
        entry = self.lib.get(entry_id)
        if not self._can_manage(event, entry, delete=True):
            return [event.plain_result("❌ 只有管理员或图片上传者可以删除图片。")]
        entry, _trash_id = self.lib.delete(entry.id)
        return [
            event.plain_result(
                f"🗑️ #{short_id(entry.id)} 已移入回收站。\n"
                "管理员可用 /图库 回收站 查看，用 /图库 恢复 <ID> 恢复。"
            )
        ]

    async def _cmd_enable(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        entry_id, _ = self._take_id(rest)
        entry = self.lib.set_enabled(entry_id, True)
        return [event.plain_result(f"✅ #{short_id(entry.id)} 已启用。")]

    async def _cmd_disable(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        entry_id, _ = self._take_id(rest)
        entry = self.lib.set_enabled(entry_id, False)
        return [event.plain_result(f"⏸️ #{short_id(entry.id)} 已禁用，不会再被自动/随机发送。")]

    # ----------------------------------------------------------------- control
    async def _cmd_learnmode(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        state = self._state_for(event)
        current = bool(state.get("learn", False))
        value = self._parse_toggle(rest, current)
        state["learn"] = value
        self._save_state()
        if value:
            text = (
                "🧠 本会话已开启学习模式。\n"
                "之后带文字说明的图片会自动入库；没有文字说明的图片会跳过。\n"
                "再次发送 /图库 学习模式 关 可停止。"
            )
        else:
            text = "🧠 本会话已关闭学习模式。"
        return [event.plain_result(text)]

    async def _cmd_auto(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        state = self._state_for(event)
        current = bool(state.get("auto", False))
        value = self._parse_toggle(rest, current)
        state["auto"] = value
        self._save_state()
        if not value:
            return [event.plain_result("🔕 本会话已关闭自动发图。")]
        if not self.lib.entries:
            return [
                event.plain_result(
                    "⚠️ 自动发图已开启，但图库还是空的。先上传几张带标签的图片吧。"
                )
            ]
        wake_note = ""
        if not event.is_private_chat() and self._cfg_bool("auto_send_require_wake", True):
            wake_note = "\n群聊中需要 @机器人 或使用唤醒词才会触发。"
        return [
            event.plain_result(
                "🔔 本会话已开启自动发图：消息命中标签时会发送图片。"
                + wake_note
                + "\n发送 /图库 自动 关 可关闭。"
            )
        ]

    async def _cmd_like(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        return await self._feedback_command(event, rest, positive=True)

    async def _cmd_dislike(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        return await self._feedback_command(event, rest, positive=False)

    async def _feedback_command(
        self, event: AstrMessageEvent, rest: str, *, positive: bool
    ) -> list[Any]:
        entry_id, _ = self._take_id(rest) if rest.strip() else ("", "")
        state = self._state_for(event)
        if not entry_id:
            pending = state.get("pending")
            if isinstance(pending, dict):
                entry_id = str(pending.get("entry_id", ""))
        if not entry_id:
            return [
                event.plain_result(
                    "请提供图片 ID，或先在自动发图后直接回复 /图库 赞 / 踩。"
                )
            ]
        try:
            entry = self.lib.get(entry_id)
            entry = self.lib.feedback(entry.id, positive)
        except ImageLibraryError as exc:
            return [event.plain_result(f"❌ {exc}")]
        state["pending"] = None
        self._save_state()
        icon = "👍" if positive else "👎"
        return [
            event.plain_result(
                f"{icon} 已记录对 #{short_id(entry.id)} 的评价："
                f"赞 {entry.likes} / 踩 {entry.dislikes}"
                + ("（已暂时降低推荐）" if not positive else "")
            )
        ]

    # ------------------------------------------------------------------ admin
    async def _cmd_stats(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        stats = self.lib.stats()
        state = self._state_for(event)
        top_tags = "、".join(f"{tag}×{count}" for tag, count in stats["top_tags"]) or "暂无"
        lines = [
            "📊 图库统计",
            f"图片：{stats['total']} 张（启用 {stats['enabled']} / 停用 {stats['disabled']}）",
            f"占用：{human_size(stats['total_size'])} · 回收站 {stats['trash']} 条",
            f"使用：{stats['uses']} 次 · 👍 {stats['likes']} · 👎 {stats['dislikes']}",
            f"热门标签：{top_tags}",
            f"本会话：学习模式 {'开' if state.get('learn') else '关'} · "
            f"自动发图 {'开' if state.get('auto') else '关'}",
        ]
        if stats["newest"]:
            lines.append(f"最近入库：{self._fmt_time(stats['newest'])}")
        return [event.plain_result("\n".join(lines))]

    async def _cmd_trash(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        page = self._parse_page(rest)
        records = self.lib.list_trash(limit=1000)
        if not records:
            return [event.plain_result("♻️ 回收站是空的。")]
        page_size = max(1, self._cfg_int("page_size", 8))
        pages = max(1, (len(records) + page_size - 1) // page_size)
        page = min(page, pages)
        start = (page - 1) * page_size
        lines = [f"♻️ 回收站 · 共 {len(records)} 条 · 第 {page}/{pages} 页"]
        for record in records[start : start + page_size]:
            entry_id = record.get("entry_id", "")
            tags = ", ".join(record.get("tags", []) or []) or "无标签"
            reason = record.get("reason", "")
            lines.append(
                f"#{short_id(entry_id)} [{reason}] {tags} · "
                f"{self._fmt_time(record.get('deleted_at', 0))}"
            )
        lines.append("恢复：/图库 恢复 <ID>")
        return [event.plain_result("\n".join(lines))]

    async def _cmd_restore(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        key = rest.strip().lstrip("#＃")
        if not key:
            return [event.plain_result("用法：/图库 恢复 <ID>（可在回收站列表查看）")]
        try:
            entry = self.lib.restore(key)
        except ImageLibraryError as exc:
            return [event.plain_result(f"❌ {exc}")]
        return [
            event.plain_result(
                f"✅ 已恢复 #{short_id(entry.id)}：{', '.join(entry.tags) or '无标签'}"
            )
        ]

    async def _cmd_emptytrash(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        if rest.strip().lower() not in {"confirm", "确认"}:
            return [
                event.plain_result(
                    "⚠️ 这会永久删除回收站中的全部图片。\n"
                    "确认请发送：/图库 清空回收站 confirm"
                )
            ]
        removed = self.lib.empty_trash()
        return [event.plain_result(f"🗑️ 已永久删除回收站中的 {removed} 个目录。")]

    async def _cmd_repair(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        report = self.lib.repair()
        return [
            event.plain_result(
                "🛠️ 修复完成：\n"
                f"清理失效索引：{report['missing_removed']} 条\n"
                f"移走孤立文件：{report['orphans_moved']} 个"
                + ("\n孤立文件已放入回收站的 _orphans 目录。" if report["orphans_moved"] else "")
            )
        ]

    async def _cmd_prune(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        removed = self.lib.enforce_capacity()
        purged = self.lib.purge_trash()
        return [
            event.plain_result(
                f"🧹 已清理 {removed} 张超出上限的图片，"
                f"并清除 {purged} 个过期回收站目录。"
            )
        ]

    async def _cmd_clear(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        denied = self._admin_denied(event)
        if denied:
            return [denied]
        if rest.strip().lower() not in {"confirm", "确认"}:
            return [
                event.plain_result(
                    "⚠️ 这会清空图库，但图片会先进入回收站。\n"
                    "确认请发送：/图库 清空 confirm"
                )
            ]
        removed = self.lib.clear()
        return [
            event.plain_result(
                f"🗑️ 已将 {removed} 张图片移入回收站。\n"
                "确认无误后可发送 /图库 清空回收站 confirm 永久删除。"
            )
        ]

    async def _cmd_help(self, event: AstrMessageEvent, rest: str) -> list[Any]:
        return [event.plain_result(HELP_TEXT)]

    def _admin_denied(self, event: AstrMessageEvent) -> Any:
        if self._is_admin(event):
            return None
        return event.plain_result("❌ 该操作仅限管理员。")

    # --------------------------------------------------------------- passive
    @filter.event_message_type(filter.EventMessageType.ALL, priority=100)
    async def on_message(self, event: AstrMessageEvent):
        try:
            result = await self._handle_passive(event)
            if result is not None:
                yield result
        except Exception:
            self.logger.exception("智能图库被动处理失败")

    async def _handle_passive(self, event: AstrMessageEvent) -> Any:
        text = str(event.message_str or "").strip()
        images = self._extract_images(event)
        command_like = self._looks_like_command(text)
        self._sync_limits()

        async with self._lock:
            state = self._state_for(event)
            dirty = False
            feedback_handled = False

            # 1) 学习模式：带文字说明的图片自动入库。
            if (
                state.get("learn")
                and images
                and not command_like
                and text
                and not should_skip_learning(text)
                and (
                    self._cfg_bool("allow_member_upload", True)
                    or self._is_admin(event)
                )
            ):
                caption = re.sub(r"\s+", " ", text).strip()[:400]
                tags = extract_hashtags(caption) + extract_keywords(
                    caption, limit=self._cfg_int("max_tags", 12)
                )
                tags = clean_tags(tags, max_tags=self._cfg_int("max_tags", 12))
                if tags:
                    for component in images[:5]:
                        try:
                            result = await self._save_component(
                                component,
                                tags=tags,
                                caption=caption,
                                source="auto-learn",
                                event=event,
                            )
                            if result.created:
                                self.logger.info(
                                    "自动学习图片 #%s 标签=%s",
                                    short_id(result.entry.id),
                                    tags,
                                )
                        except Exception as exc:
                            self.logger.debug("自动学习跳过一张图片：%s", exc)
                    state["updated_at"] = time.time()
                    dirty = True

            # 2) 自动反馈学习：评价上一张自动发送的图片。
            pending = state.get("pending")
            if isinstance(pending, dict) and not command_like:
                try:
                    pending_at = float(pending.get("at", 0) or 0)
                except (TypeError, ValueError):
                    pending_at = 0
                if time.time() - pending_at > 180:
                    state["pending"] = None
                    dirty = True
                else:
                    signal = feedback_signal(text)
                    if signal and self._cfg_bool("feedback_learning", True):
                        entry_id = str(pending.get("entry_id", ""))
                        try:
                            entry = self.lib.feedback(entry_id, signal > 0)
                            if signal > 0:
                                extra = [
                                    tag
                                    for tag in extract_keywords(text, limit=3)
                                    if 2 <= len(tag) <= 10
                                ][:2]
                                if extra:
                                    self.lib.add_tags(entry.id, extra)
                            state["pending"] = None
                            dirty = True
                            feedback_handled = True
                        except Exception:
                            state["pending"] = None
                            dirty = True

            # 3) 自动发图。
            if (
                state.get("auto")
                and not command_like
                and not feedback_handled
                and not images
                and text
                and not should_skip_auto_send(text)
            ):
                if (
                    event.is_private_chat()
                    or event.is_at_or_wake_command
                    or not self._cfg_bool("auto_send_require_wake", True)
                ):
                    now = time.time()
                    cooldown = max(0, self._cfg_int("auto_send_cooldown", 90))
                    daily_limit = max(1, self._cfg_int("auto_send_daily_limit", 30))
                    try:
                        last_auto = float(state.get("last_auto_at", 0) or 0)
                    except (TypeError, ValueError):
                        last_auto = 0
                    times = [
                        float(item)
                        for item in state.get("auto_times", [])
                        if isinstance(item, (int, float))
                        and now - float(item) < 86400
                    ]
                    if now - last_auto >= cooldown and len(times) < daily_limit:
                        score_value = self._cfg_float("auto_send_min_score", 0.75)
                        if score_value > 1.0:
                            score_value /= 100.0
                        threshold = max(0.05, min(1.0, score_value))
                        recent_ids = state.get("recent", [])
                        if not isinstance(recent_ids, list):
                            recent_ids = []
                        found = self.lib.find_best(
                            text,
                            threshold=threshold,
                            exclude_ids=recent_ids,
                        )
                        if found is not None:
                            entry, _score = found
                            try:
                                chain: list[Any] = [await self._image_component(entry)]
                            except Exception as exc:
                                self.logger.warning("自动发图读取失败：%s", exc)
                                chain = []
                            if chain:
                                self.lib.record_use(entry.id)
                                previous_recent = state.get("recent", [])
                                if not isinstance(previous_recent, list):
                                    previous_recent = []
                                recent = [entry.id] + [
                                    item
                                    for item in previous_recent
                                    if item != entry.id
                                ][:4]
                                state["recent"] = recent
                                state["last_auto_at"] = now
                                state["auto_times"] = times + [now]
                                state["pending"] = {
                                    "entry_id": entry.id,
                                    "at": now,
                                    "query": text[:100],
                                }
                                state["updated_at"] = now
                                dirty = True
                                if self._cfg_bool("auto_send_block_llm", True):
                                    # 只阻止默认 LLM 接话，不打断其他插件/事件链。
                                    try:
                                        event.should_call_llm(False)
                                    except AttributeError:
                                        pass
                                if self._cfg_bool("show_tags", False):
                                    chain.append(Comp.Plain("\n" + self._entry_line(entry)))
                                if dirty:
                                    self._save_state()
                                return event.chain_result(chain)

            if dirty:
                self._save_state()
        return None

    # ---------------------------------------------------------------- helpers
    def _looks_like_command(self, text: str) -> bool:
        original = str(text or "").strip()
        if original.startswith(("/", "!", "！", ".")):
            return True
        raw = re.sub(r"^\s+", "", original)
        if not raw:
            return False
        head = raw.split(maxsplit=1)[0].split("@", 1)[0].lower()
        return head in COMMAND_NAMES

    def _extract_images(self, event: AstrMessageEvent) -> list[Any]:
        result: list[Any] = []
        seen: set[int] = set()

        def walk(chain: Any, depth: int = 0) -> None:
            if depth > 4 or not chain:
                return
            for component in chain:
                try:
                    if isinstance(component, Comp.Image):
                        if id(component) not in seen:
                            seen.add(id(component))
                            result.append(component)
                        continue
                    for attr in ("chain", "content"):
                        nested = getattr(component, attr, None)
                        if nested:
                            walk(nested, depth + 1)
                    nodes = getattr(component, "nodes", None)
                    if nodes:
                        walk(nodes, depth + 1)
                except Exception:
                    continue

        walk(event.get_messages())
        return result

    async def _save_component(
        self,
        component: Any,
        *,
        tags: Iterable[str],
        caption: str,
        source: str,
        event: AstrMessageEvent,
    ):
        path = await self._component_to_path(component)
        try:
            return await asyncio.to_thread(
                self.lib.add_from_path,
                path,
                tags=tags,
                caption=caption,
                source=source,
                uploader_id=str(event.get_sender_id() or ""),
                uploader_name=str(event.get_sender_name() or ""),
            )
        finally:
            if path in self._temp_paths:
                self._temp_paths.discard(path)
                try:
                    path.unlink()
                except OSError:
                    pass

    async def _component_to_path(self, component: Any) -> Path:
        last_error: Exception | None = None
        converter = getattr(component, "convert_to_file_path", None)
        if callable(converter):
            try:
                path = await converter()
                if path and Path(path).is_file():
                    return Path(path)
            except Exception as exc:
                last_error = exc

        for attr in ("path", "file", "url"):
            value = getattr(component, attr, None)
            if not value:
                continue
            try:
                return await self._resource_to_path(str(value))
            except Exception as exc:
                last_error = exc
        raise ImageLibraryError(
            f"无法读取图片内容，请确认图片已成功上传（{last_error or '未知错误'}）。"
        )

    async def _resource_to_path(self, resource: str) -> Path:
        if resource.startswith("file://"):
            parsed = urllib.parse.urlparse(resource)
            path = Path(urllib.parse.unquote(parsed.path))
            if os.name == "nt" and path.as_posix().startswith("/"):
                path = Path(path.as_posix().lstrip("/"))
            if path.is_file():
                return path
            raise ImageLibraryError("本地图片文件不存在。")
        if resource.startswith("base64://"):
            return self._write_temp(base64.b64decode(resource[len("base64://") :]))
        if resource.startswith("data:image/") and ";base64," in resource:
            return self._write_temp(base64.b64decode(resource.split(";base64,", 1)[1]))
        if resource.startswith(("http://", "https://")):
            return await self._download_to_temp(resource)
        path = Path(resource)
        if path.is_file():
            return path
        raise ImageLibraryError("图片引用不是可读取的本地文件或 URL。")

    def _write_temp(self, data: bytes) -> Path:
        if len(data) > self.lib.max_bytes:
            raise ImageTooLarge(
                f"图片超过 {self.lib.max_file_mb} MB 限制（当前 {human_size(len(data))}）。"
            )
        handle, path = tempfile.mkstemp(prefix="astrbot_smart_image_", suffix=".img")
        with os.fdopen(handle, "wb") as file:
            file.write(data)
        result = Path(path).resolve()
        self._temp_paths.add(result)
        return result

    async def _download_to_temp(self, url: str) -> Path:
        limit = self.lib.max_bytes

        def download() -> Path:
            request = urllib.request.Request(
                url, headers={"User-Agent": "AstrBot-SmartImage/1.0"}
            )
            with urllib.request.urlopen(request, timeout=25) as response:
                data = response.read(limit + 1)
            if len(data) > limit:
                raise ImageTooLarge(f"图片超过 {self.lib.max_file_mb} MB 限制。")
            return self._write_temp(data)

        return await asyncio.to_thread(download)

    async def _validate_url(self, url: str) -> None:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ImageLibraryError("只支持 http/https 图片链接。")
        if self._cfg_bool("allow_private_url", False):
            return
        try:
            infos = await asyncio.wait_for(
                asyncio.to_thread(
                    socket.getaddrinfo,
                    parsed.hostname,
                    80,
                    type=socket.SOCK_STREAM,
                ),
                timeout=8,
            )
        except (OSError, asyncio.TimeoutError) as exc:
            raise ImageLibraryError(f"域名解析失败：{exc}") from exc
        for info in infos:
            address = info[4][0]
            try:
                ip = ipaddress.ip_address(address)
            except ValueError:
                continue
            if not ip.is_global:
                raise ImageLibraryError("出于安全考虑，不允许导入内网/保留地址的图片。")

    async def _image_component(self, entry: ImageEntry) -> Any:
        path = self.lib.entry_path(entry)
        if not path.is_file():
            raise ImageLibraryError(f"#{short_id(entry.id)} 的图片文件已丢失。")

        base_url = str(self._cfg("public_base_url", "") or "").strip().rstrip("/")
        if base_url:
            filename = urllib.parse.quote(entry.file)
            return Comp.Image.fromURL(f"{base_url}/{filename}")

        if self._cfg_bool("use_file_service", False):
            try:
                image = Comp.Image.fromFileSystem(str(path))
                url = await asyncio.wait_for(image.register_to_file_service(), timeout=8)
                if url:
                    return Comp.Image.fromURL(url)
            except Exception as exc:
                self.logger.debug("文件服务注册失败，回退到本地文件：%s", exc)

        return Comp.Image.fromFileSystem(str(path))

    def _entry_line(self, entry: ImageEntry) -> str:
        tags = ", ".join(entry.tags) or "无标签"
        line = f"#{short_id(entry.id)} {tags}"
        if entry.caption:
            caption = entry.caption
            if len(caption) > 60:
                caption = caption[:60] + "…"
            line += f" | {caption}"
        return line

    def _entry_details(self, entry: ImageEntry) -> str:
        status = "启用" if entry.enabled else "停用"
        source_map = {
            "upload": "聊天上传",
            "url": "链接导入",
            "learned": "手动学习",
            "auto-learn": "自动学习",
        }
        source = source_map.get(entry.source, entry.source or "未知")
        uploader = entry.uploader_name or "未知"
        if entry.uploader_id:
            uploader += f"（{entry.uploader_id}）"
        dimensions = (
            f"{entry.width}×{entry.height}" if entry.width and entry.height else "未知"
        )
        return (
            f"🖼️ #{short_id(entry.id)}\n"
            f"标签：{', '.join(entry.tags) or '无'}\n"
            f"描述：{entry.caption or '无'}\n"
            f"状态：{status} · 来源：{source}\n"
            f"上传者：{uploader}\n"
            f"尺寸：{dimensions} · 大小：{human_size(entry.size)}\n"
            f"入库：{self._fmt_time(entry.created_at)}\n"
            f"最近使用：{self._fmt_time(entry.last_used_at) if entry.last_used_at else '从未'}\n"
            f"使用 {entry.uses} 次 · 👍 {entry.likes} · 👎 {entry.dislikes}"
        )

    @staticmethod
    def _fmt_time(timestamp: Any) -> str:
        try:
            value = float(timestamp or 0)
        except (TypeError, ValueError):
            return "未知"
        if value <= 0:
            return "未知"
        return datetime.fromtimestamp(value).strftime("%Y-%m-%d %H:%M")

    @staticmethod
    def _parse_toggle(text: str, current: bool) -> bool:
        value = normalize_text(text)
        if not value:
            return not current
        if value in {"开", "开启", "打开", "on", "true", "1", "yes", "启用"}:
            return True
        if value in {"关", "关闭", "off", "false", "0", "no", "禁用"}:
            return False
        return not current

    async def terminate(self) -> None:
        try:
            self._save_state()
        except Exception:
            self.logger.exception("保存智能图库状态失败")
        for path in list(self._temp_paths):
            try:
                path.unlink()
            except OSError:
                pass
        self._temp_paths.clear()
